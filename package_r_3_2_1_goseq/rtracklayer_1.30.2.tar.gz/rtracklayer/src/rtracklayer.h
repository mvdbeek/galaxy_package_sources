#ifndef RTRACKLAYER_H
#define RTRACKLAYER_H

#include <Rinternals.h>

#include <S4Vectors_interface.h>
#include <IRanges_interface.h>
#include <XVector_interface.h>

#endif
