datacache <- new.env(hash=TRUE, parent=emptyenv())

org.Hs.ipi_dbconn <- function() dbconn(datacache)
org.Hs.ipi_dbfile <- function() dbfile(datacache)
org.Hs.ipi_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, 
    file=file, show.indices=show.indices)
org.Hs.ipi_dbInfo <- function() dbInfo(datacache)
org.Hs.ipiORGANISM <- "Homo sapiens"

.onLoad <- function(libname, pkgname)
{
    require("methods", quietly=TRUE)
    require("PAnnBuilder", quietly=TRUE)
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "org.Hs.ipi.sqlite", package="org.Hs.ipi.db", 
        lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs("IPI", "org.Hs.ipi", datacache, dbconn)    
    mergeToNamespaceAndExport(ann_objs, "org.Hs.ipi.db" )
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(org.Hs.ipi_dbconn())
}

