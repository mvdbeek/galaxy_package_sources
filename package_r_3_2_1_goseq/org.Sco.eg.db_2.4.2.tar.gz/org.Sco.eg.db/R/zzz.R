datacache <- new.env(hash=TRUE, parent=emptyenv())

org.Sco.eg <- function() showQCData("org.Sco.eg", datacache)
org.Sco.eg_dbconn <- function() dbconn(datacache)
org.Sco.eg_dbfile <- function() dbfile(datacache)
org.Sco.eg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
org.Sco.eg_dbInfo <- function() dbInfo(datacache)

org.Sco.egORGANISM <- "Streptomyces coelicolor"

.onLoad <- function(libname, pkgname)
{
    require("methods", quietly=TRUE)
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "org.Sco.eg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("COELICOLOR_DB", "org.Sco.eg", "Streptomyces coelicolor", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("org.Sco.eg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(org.Sco.eg_dbconn())
}

