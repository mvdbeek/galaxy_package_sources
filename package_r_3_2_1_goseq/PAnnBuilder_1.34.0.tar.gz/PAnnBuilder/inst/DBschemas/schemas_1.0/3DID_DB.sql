--
-- 3DID_DB schema
-- ===============
--

CREATE TABLE did (
  pfam_a VARCHAR(10) NOT NULL,               -- Pfam domain ID
  pfam_b VARCHAR(10) NOT NULL,         -- Pfam domain ID
);
