descriptionInfo <- read.table("descriptionInfo.txt", header=TRUE, sep="\t")
