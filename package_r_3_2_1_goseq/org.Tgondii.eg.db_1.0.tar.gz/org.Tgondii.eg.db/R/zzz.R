datacache <- new.env(hash=TRUE, parent=emptyenv())

org.Tgondii.eg <- function() showQCData("org.Tgondii.eg", datacache)
org.Tgondii.eg_dbconn <- function() dbconn(datacache)
org.Tgondii.eg_dbfile <- function() dbfile(datacache)
org.Tgondii.eg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
org.Tgondii.eg_dbInfo <- function() dbInfo(datacache)

org.Tgondii.egORGANISM <- "Toxoplasma gondii"

.onLoad <- function(libname, pkgname)
{
    require("methods", quietly=TRUE)
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "org.Tgondii.eg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    txdb <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"OrgDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, txdb, envir=ns)
    namespaceExport(ns, dbNewname)
        
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("ORGANISM_DB", "org.Tgondii.eg", "chip org.Tgondii.eg", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("org.Tgondii.eg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(org.Tgondii.eg_dbconn())
}

