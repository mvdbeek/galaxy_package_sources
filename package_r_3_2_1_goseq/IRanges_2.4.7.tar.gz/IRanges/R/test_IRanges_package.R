.test <- function() BiocGenerics:::testPackage("IRanges")
